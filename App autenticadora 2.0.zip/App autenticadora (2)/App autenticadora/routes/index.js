import { Router } from  "express";
const router = Router();

router.get("/users", (req,res)=>{
});
res.send("hola desde la ruta de users")
export default router;